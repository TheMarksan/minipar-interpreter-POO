"""
Módulo de geração de código para MiniPar
"""

from .TACGenerator import TACGenerator, TACInstruction

__all__ = ['TACGenerator', 'TACInstruction']
